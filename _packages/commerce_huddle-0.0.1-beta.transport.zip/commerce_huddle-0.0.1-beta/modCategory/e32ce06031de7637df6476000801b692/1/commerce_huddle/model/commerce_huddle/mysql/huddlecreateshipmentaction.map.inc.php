<?php
/**
 * @package commerce_huddle
 */
$xpdo_meta_map['HuddleCreateShipmentAction']= array (
  'package' => 'commerce_huddle',
  'version' => '1.1',
  'extends' => 'comStatusChangeAction',
  'tableMeta' => 
  array (
    'engine' => 'InnoDB',
  ),
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
