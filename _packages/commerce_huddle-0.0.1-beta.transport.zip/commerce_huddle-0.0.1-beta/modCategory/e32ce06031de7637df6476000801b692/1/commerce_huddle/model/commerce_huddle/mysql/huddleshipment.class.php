<?php
/**
 * @package commerce_huddle
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/huddleshipment.class.php');
class HuddleShipment_mysql extends HuddleShipment {}
?>