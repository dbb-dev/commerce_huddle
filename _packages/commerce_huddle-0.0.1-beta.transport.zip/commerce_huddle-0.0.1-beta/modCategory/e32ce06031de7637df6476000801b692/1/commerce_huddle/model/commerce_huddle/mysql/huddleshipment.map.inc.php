<?php
/**
 * @package commerce_huddle
 */
$xpdo_meta_map['HuddleShipment']= array (
  'package' => 'commerce_huddle',
  'version' => '1.1',
  'extends' => 'comOrderShipment',
  'tableMeta' => 
  array (
    'engine' => 'InnoDB',
  ),
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
