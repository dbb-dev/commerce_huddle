<?php
/**
 * @package commerce_huddle
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/huddlecreateshipmentaction.class.php');
class HuddleCreateShipmentAction_mysql extends HuddleCreateShipmentAction {}
?>